/**
 * Copyright: Derick Augustine Coutinho
 */
package edu.gmu.processor;

import org.apache.commons.lang3.StringUtils;

import edu.gmu.bean.DataBean;

/**
 * This class is the processor class in which all the data processing is
 * performed.
 * 
 * @author Derick Augustine Coutinho
 * @version 0.1
 * @since 2nd Nov 2014
 */
public class DataProcessor {

	/**
	 * This method is used to calculate the mean and the standard deviation of
	 * the numbers entered by the student.
	 * 
	 * @param dataField
	 */
	public DataBean calculateMeanStandardDeviation(String dataField) {
		String[] dataFieldsArr = null;
		if (StringUtils.isNotEmpty(dataField)) {
			dataFieldsArr = StringUtils.split(dataField, ",");
		}
		DataBean dataBean = null;

		if (null != dataFieldsArr) {
			double mean = 0;
			double sum = 0;
			double squareSum = 0;
			double stndrdDeviation = 0;

			// First for loop to calculate the mean.
			for (String meanData : dataFieldsArr) {
				sum = sum + Integer.parseInt(meanData);
			}

			mean = sum / dataFieldsArr.length;

			// Second for loop to calculate the standard deviation.
			for (String sdData : dataFieldsArr) {
				double square = Math.pow((Integer.parseInt(sdData) - mean), 2);

				squareSum = squareSum + square;
			}

			stndrdDeviation = Math.sqrt(squareSum / (dataFieldsArr.length - 1));

			dataBean = new DataBean();
			dataBean.setDataNumbers(dataField);
			dataBean.setMeanValue(mean);
			dataBean.setStandardDeviationVal(stndrdDeviation);
		}

		return dataBean;
	}
}