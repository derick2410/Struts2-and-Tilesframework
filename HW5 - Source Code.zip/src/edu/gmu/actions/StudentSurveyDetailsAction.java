/**
 * Copyright: Derick Augustine Coutinho
 */
package edu.gmu.actions;

import org.apache.commons.lang3.StringUtils;

import com.opensymphony.xwork2.ActionSupport;

import edu.gmu.bean.DataBean;
import edu.gmu.bean.StudentBean;
import edu.gmu.dao.StudentDAO;
import edu.gmu.processor.DataProcessor;

/**
 * This is the action class to save the student survey details into the
 * database.
 * 
 * @author Derick Augustine Coutinho
 * @since 11/29/2014
 * @version 0.1
 */
public class StudentSurveyDetailsAction extends ActionSupport {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Student bean to display the student survey details to the user.
	 */
	private StudentBean studentBean;

	/**
	 * Data bean to display the mean and standard deviation to the user.
	 */
	private DataBean dataBean;

	/**
	 * This method is only used to load the student survey form JSP for the
	 * tiles purpose.
	 * 
	 * @return
	 */
	public String loadStudentSurveyForm() {
		return "success";
	}

	/**
	 * This method is used to save the students survey details into the database
	 * and also retrieve all the students ID's those have taken the survey
	 * earlier.
	 * 
	 * @return resultName
	 */
	public String saveSurveyDetails() {

		StudentDAO studentDAO = new StudentDAO();
		// Save current student survey details.
		studentDAO.saveStudentSurveyInfo(studentBean);

		// Retrieve all the student ID's and set it into the student bean.
		studentBean.setStudentIds(studentDAO.retrieveStudentIds());

		// Calculate Mean and Standard Deviation of the numbers.
		DataProcessor dataProcessor = new DataProcessor();
		dataBean = dataProcessor.calculateMeanStandardDeviation(dataBean
				.getDataNumbers());

		String resultName = StringUtils.EMPTY;

		if (null != dataBean && dataBean.getMeanValue() > 90) {
			// WinnerAcknowledgement JSP
			resultName = "winnerAcknowledgement";
		} else {
			// SimpleAcknowledgement JSP
			resultName = "simpleAcknowledgement";
		}

		return resultName;
	}

	/**
	 * This method is used to retrieve the student survey details from the
	 * database from the given student ID when the user clicks on the particular
	 * student ID link.
	 * 
	 * @return resultName
	 */
	public String retrieveStudentDetails() {
		StudentDAO studentDAO = new StudentDAO();
		/*
		 * Retrieve student survey details from the database from the provided
		 * student ID.
		 */
		studentBean = studentDAO.retrieveStudentSurveyInfo(studentBean
				.getStudentId());

		String resultName = StringUtils.EMPTY;
		if (null != studentBean) {
			// If student is present
			resultName = "student";
		} else {
			// If no student of this ID is not present.
			resultName = "noStudent";
		}

		return resultName;
	}

	/**
	 * @return the studentBean
	 */
	public StudentBean getStudentBean() {
		return studentBean;
	}

	/**
	 * @param studentBean
	 *            the studentBean to set
	 */
	public void setStudentBean(StudentBean studentBean) {
		this.studentBean = studentBean;
	}

	/**
	 * @return the dataBean
	 */
	public DataBean getDataBean() {
		return dataBean;
	}

	/**
	 * @param dataBean
	 *            the dataBean to set
	 */
	public void setDataBean(DataBean dataBean) {
		this.dataBean = dataBean;
	}
}