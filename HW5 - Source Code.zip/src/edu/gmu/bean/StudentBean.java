/**
 * Copyright: Derick Augustine Coutinho
 */
package edu.gmu.bean;

import java.util.ArrayList;

/**
 * This class is a POJO class in which all the student details bean are present.
 * 
 * @author Derick Augustine Coutinho
 * @version 0.1
 * @since 2nd Nov 2014
 */
public class StudentBean {
	private String studentId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String studentName;
	private String streetAddr;
	private String zipCode;
	private String cityDiv;
	private String stateDiv;
	private String telNum;
	private String emailAddr;
	private String gradMonth;
	private String gradYear;
	private String url;
	private String dateOfSurvey;
	private String recommendation;
	private String interest;
	private String likings;
	private ArrayList<String> studentIds;

	/**
	 * @return the studentId
	 */
	public String getStudentId() {
		return studentId;
	}

	/**
	 * @param studentId
	 *            the studentId to set
	 */
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName
	 *            the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the studentName
	 */
	public String getStudentName() {
		StringBuilder nameBuilder = new StringBuilder();
		nameBuilder.append(firstName);
		nameBuilder.append(" ");
		nameBuilder.append(middleName);
		nameBuilder.append(" ");
		nameBuilder.append(lastName);

		if (null != firstName) {
			studentName = nameBuilder.toString();
		}

		return studentName;
	}

	/**
	 * @param studentName
	 *            the studentName to set
	 */
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	/**
	 * @return the streetAddr
	 */
	public String getStreetAddr() {
		return streetAddr;
	}

	/**
	 * @param streetAddr
	 *            the streetAddr to set
	 */
	public void setStreetAddr(String streetAddr) {
		this.streetAddr = streetAddr;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode
	 *            the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the cityDiv
	 */
	public String getCityDiv() {
		return cityDiv;
	}

	/**
	 * @param cityDiv
	 *            the cityDiv to set
	 */
	public void setCityDiv(String cityDiv) {
		this.cityDiv = cityDiv;
	}

	/**
	 * @return the stateDiv
	 */
	public String getStateDiv() {
		return stateDiv;
	}

	/**
	 * @param stateDiv
	 *            the stateDiv to set
	 */
	public void setStateDiv(String stateDiv) {
		this.stateDiv = stateDiv;
	}

	/**
	 * @return the telNum
	 */
	public String getTelNum() {
		return telNum;
	}

	/**
	 * @param telNum
	 *            the telNum to set
	 */
	public void setTelNum(String telNum) {
		this.telNum = telNum;
	}

	/**
	 * @return the emailAddr
	 */
	public String getEmailAddr() {
		return emailAddr;
	}

	/**
	 * @param emailAddr
	 *            the emailAddr to set
	 */
	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	/**
	 * @return the gradMonth
	 */
	public String getGradMonth() {
		return gradMonth;
	}

	/**
	 * @param gradMonth
	 *            the gradMonth to set
	 */
	public void setGradMonth(String gradMonth) {
		this.gradMonth = gradMonth;
	}

	/**
	 * @return the gradYear
	 */
	public String getGradYear() {
		return gradYear;
	}

	/**
	 * @param gradYear
	 *            the gradYear to set
	 */
	public void setGradYear(String gradYear) {
		this.gradYear = gradYear;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the dateOfSurvey
	 */
	public String getDateOfSurvey() {
		return dateOfSurvey;
	}

	/**
	 * @param dateOfSurvey
	 *            the dateOfSurvey to set
	 */
	public void setDateOfSurvey(String dateOfSurvey) {
		this.dateOfSurvey = dateOfSurvey;
	}

	/**
	 * @return the recommendation
	 */
	public String getRecommendation() {
		return recommendation;
	}

	/**
	 * @param recommendation
	 *            the recommendation to set
	 */
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}

	/**
	 * @return the interest
	 */
	public String getInterest() {
		return interest;
	}

	/**
	 * @param interest
	 *            the interest to set
	 */
	public void setInterest(String interest) {
		this.interest = interest;
	}

	/**
	 * @return the likings
	 */
	public String getLikings() {
		return likings;
	}

	/**
	 * @param likings
	 *            the likings to set
	 */
	public void setLikings(String likings) {
		this.likings = likings;
	}

	/**
	 * @return the studentIds
	 */
	public ArrayList<String> getStudentIds() {
		return studentIds;
	}

	/**
	 * @param studentIds
	 *            the studentIds to set
	 */
	public void setStudentIds(ArrayList<String> studentIds) {
		this.studentIds = studentIds;
	}
}